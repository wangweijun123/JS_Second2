package com.example.bledemo.slice;

import com.example.bledemo.ResourceTable;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.aafwk.content.IntentParams;
import ohos.bluetooth.BluetoothHost;
import ohos.bluetooth.BluetoothRemoteDevice;
import ohos.bluetooth.ble.BleCentralManager;
import ohos.bluetooth.ble.BleCentralManagerCallback;
import ohos.bluetooth.ble.BleScanFilter;
import ohos.bluetooth.ble.BleScanResult;
import ohos.event.commonevent.*;
import ohos.rpc.RemoteException;
import ohos.wifi.WifiEvents;

import java.util.ArrayList;
import java.util.List;

public class OldBlutoothAbilitySlice extends AbilitySlice {
    static  String TAG = "MainAbilitySlice";
    // 获取蓝牙本机管理对象
    BluetoothHost bluetoothHost;
    //接收系统广播
     class MyCommonEventSubscriber extends CommonEventSubscriber {

        public MyCommonEventSubscriber(CommonEventSubscribeInfo subscribeInfo) {
            super(subscribeInfo);
        }

        @Override
        public void onReceiveEvent(CommonEventData var){
            Intent info = var.getIntent();
            if(info == null) return;
            //获取系统广播的action
            String action = info.getAction();
            //判断是否为扫描到设备的广播
            if(action == BluetoothRemoteDevice.EVENT_DEVICE_DISCOVERED){
                IntentParams myParam = info.getParams();
                BluetoothRemoteDevice device = (BluetoothRemoteDevice)myParam
                        .getParam(BluetoothRemoteDevice.REMOTE_DEVICE_PARAM_DEVICE);
                String deviceAddr = device.getDeviceAddr();
                BluetoothRemoteDevice remoteDev = bluetoothHost.getRemoteDev(deviceAddr);
                remoteDev.startPair();
            }
        }
    }

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_main);

        startOldScan();
    }

    private void startOldScan() {
         register();

        bluetoothHost = BluetoothHost.getDefaultHost(getContext());
        // 调用打开接口
        bluetoothHost.enableBt();
        // 调用获取蓝牙开关状态接口
        int state = bluetoothHost.getBtState();
        // 获取已配对的列表
        List<BluetoothRemoteDevice> pairedDevices = bluetoothHost.getPairedDevices();
        //开始扫描
        bluetoothHost.startBtDiscovery();

    }

    private void register() {
        // 注册消息
        MatchingSkills match = new MatchingSkills();
        // 增加获取WLAN状态变化消息
        match.addEvent(BluetoothRemoteDevice.EVENT_DEVICE_DISCOVERED);
        CommonEventSubscribeInfo subscribeInfo = new CommonEventSubscribeInfo(match);
        subscribeInfo.setPriority(100);
        MyCommonEventSubscriber subscriber = new MyCommonEventSubscriber(subscribeInfo);
        try {
            CommonEventManager.subscribeCommonEvent(subscriber);
        } catch (RemoteException e) {
        }
    }


    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
