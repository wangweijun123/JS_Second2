package com.example.js_first;

import ohos.ace.ability.AceAbility;
import ohos.aafwk.content.Intent;

/**
 * 继承AceAbility，装载js页面
 */
public class MainAbility extends AceAbility {
    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
    }

    @Override
    public void onStop() {
        super.onStop();
    }

}
