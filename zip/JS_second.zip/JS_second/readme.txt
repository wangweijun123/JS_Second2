1 js 是动态语言，就是说数据类型，在运行期间确定数据类型，java是静态类型

shell 脚本： 解释一行，运行一行

2, js 函数的返回值，直接return 值就行了，太灵活了

3, js与java都可以debug，不过只以debug运行，不能先运行，然后attach进程