/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.hml?entry");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.hml?entry":
/*!**********************************************************************************************!*\
  !*** D:/dev_hm/hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.hml?entry ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var $app_template$ = __webpack_require__(/*! !../../../../../../../../../hmSdk/js/2.1.1.20/build-tools/ace-loader/lib/json.js!../../../../../../../../../hmSdk/js/2.1.1.20/build-tools/ace-loader/lib/template.js!./index.hml */ "./lib/json.js!./lib/template.js!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.hml")
var $app_style$ = __webpack_require__(/*! !../../../../../../../../../hmSdk/js/2.1.1.20/build-tools/ace-loader/lib/json.js!../../../../../../../../../hmSdk/js/2.1.1.20/build-tools/ace-loader/lib/style.js!./index.css */ "./lib/json.js!./lib/style.js!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.css")
var $app_script$ = __webpack_require__(/*! !../../../../../../../../../hmSdk/js/2.1.1.20/build-tools/ace-loader/lib/script.js!../../../../../../../../../hmSdk/js/2.1.1.20/build-tools/ace-loader/node_modules/babel-loader?presets[]=D:/dev_hm/hmSdk/js/2.1.1.20/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/dev_hm/hmSdk/js/2.1.1.20/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!./index.js */ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.20\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.20\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.js")

$app_define$('@app-component/index', [], function($app_require$, $app_exports$, $app_module$) {

$app_script$($app_module$, $app_exports$, $app_require$)
if ($app_exports$.__esModule && $app_exports$.default) {
$app_module$.exports = $app_exports$.default
}

$app_module$.exports.template = $app_template$

$app_module$.exports.style = $app_style$

})
$app_bootstrap$('@app-component/index',undefined,undefined)

/***/ }),

/***/ "./lib/json.js!./lib/style.js!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.css":
/*!*********************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/style.js!D:/dev_hm/hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.css ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  ".container": {
    "flexDirection": "row",
    "paddingTop": "10px",
    "paddingRight": "10px",
    "paddingBottom": "10px",
    "paddingLeft": "10px"
  },
  ".left-container": {
    "flexDirection": "column",
    "weights": "1"
  },
  ".right-container": {
    "weights": "2"
  },
  ".title-text": {
    "fontSize": "30px",
    "color": "#FF7FD4",
    "marginTop": "30px",
    "backgroundColor": "#00FFFF",
    "textAlign": "center"
  },
  ".paragraph-text": {
    "color": "#000000",
    "marginBottom": "10px",
    "fontSize": "20px",
    "lineHeight": "50px",
    "backgroundColor": "#A52A2A"
  },
  ".like-container": {
    "width": "204px",
    "height": "88px",
    "borderTopWidth": "5px",
    "borderRightWidth": "5px",
    "borderBottomWidth": "5px",
    "borderLeftWidth": "5px",
    "borderTopStyle": "solid",
    "borderRightStyle": "solid",
    "borderBottomStyle": "solid",
    "borderLeftStyle": "solid",
    "borderTopColor": "#ff0000",
    "borderRightColor": "#ff0000",
    "borderBottomColor": "#ff0000",
    "borderLeftColor": "#ff0000",
    "marginBottom": "10px"
  },
  ".zan-img": {
    "objectFit": "contain"
  },
  ".number-text": {
    "width": "40px"
  },
  ".paragraphSecond-text": {
    "color": "#000000",
    "fontSize": "20px",
    "backgroundColor": "#A52A2A",
    "flexGrow": 1
  },
  ".img": {
    "width": "500px",
    "objectFit": "cover"
  },
  ".commit-text": {
    "fontSize": "50px",
    "color": "#000000",
    "backgroundColor": "#00FFFF",
    "width": "100%"
  },
  ".commit-container": {
    "flexDirection": "column",
    "textAlign": "center"
  },
  ".wrap-comment": {
    "alignItems": "center"
  },
  ".comment": {
    "height": "50px",
    "backgroundColor": "#D3D3D3"
  },
  ".done-text": {
    "fontSize": "50px",
    "color": "#000000",
    "backgroundColor": "#00FFFF",
    "width": "250px",
    "textAlign": "center"
  }
}

/***/ }),

/***/ "./lib/json.js!./lib/template.js!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.hml":
/*!************************************************************************************************************************!*\
  !*** ./lib/json.js!./lib/template.js!D:/dev_hm/hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.hml ***!
  \************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  "attr": {
    "debugLine": "pages/index/index:2",
    "className": "container"
  },
  "type": "div",
  "classList": [
    "container"
  ],
  "children": [
    {
      "attr": {
        "debugLine": "pages/index/index:5",
        "className": "left-container"
      },
      "type": "div",
      "classList": [
        "left-container"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/index/index:6",
            "className": "title-text",
            "value": function () {return this.headTitle}
          },
          "type": "text",
          "classList": [
            "title-text"
          ]
        },
        {
          "attr": {
            "debugLine": "pages/index/index:7",
            "className": "paragraph-text",
            "value": function () {return this.paragraphFirst}
          },
          "type": "text",
          "classList": [
            "paragraph-text"
          ]
        },
        {
          "attr": {
            "debugLine": "pages/index/index:9",
            "className": "like-container"
          },
          "type": "div",
          "classList": [
            "like-container"
          ],
          "events": {
            "click": "clickZan"
          },
          "children": [
            {
              "attr": {
                "debugLine": "pages/index/index:10",
                "className": "zan-img",
                "src": function () {return this.isZan?this.zanImagePressed:this.zanImageNormal}
              },
              "type": "image",
              "classList": [
                "zan-img"
              ]
            },
            {
              "attr": {
                "debugLine": "pages/index/index:11",
                "className": "number-text",
                "value": function () {return this.number}
              },
              "type": "text",
              "classList": [
                "number-text"
              ]
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/index/index:14",
            "type": "capsule",
            "value": "跳转第二个页面"
          },
          "type": "button",
          "events": {
            "click": "launch"
          }
        },
        {
          "attr": {
            "debugLine": "pages/index/index:15"
          },
          "type": "dialog",
          "children": [
            {
              "attr": {
                "debugLine": "pages/index/index:16"
              },
              "type": "list",
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/index/index:17"
                  },
                  "type": "list-item",
                  "repeat": function () {return this.persons},
                  "children": [
                    {
                      "attr": {
                        "debugLine": "pages/index/index:18",
                        "value": function () {return this.$item}
                      },
                      "type": "text"
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          "attr": {
            "debugLine": "pages/index/index:22",
            "className": "paragraphSecond-text",
            "value": function () {return this.paragraphSecond}
          },
          "type": "text",
          "classList": [
            "paragraphSecond-text"
          ]
        },
        {
          "attr": {
            "debugLine": "pages/index/index:25",
            "className": "commit-container"
          },
          "type": "div",
          "classList": [
            "commit-container"
          ],
          "children": [
            {
              "attr": {
                "debugLine": "pages/index/index:26",
                "className": "commit-text",
                "value": "评论"
              },
              "type": "text",
              "classList": [
                "commit-text"
              ],
              "shown": function () {return !this.isCommit}
            },
            {
              "attr": {
                "debugLine": "pages/index/index:27",
                "className": "commit-text",
                "value": function () {return this.inputValue}
              },
              "type": "text",
              "classList": [
                "commit-text"
              ],
              "shown": function () {return this.isCommit}
            },
            {
              "attr": {
                "debugLine": "pages/index/index:29",
                "className": "wrap-comment"
              },
              "type": "div",
              "classList": [
                "wrap-comment"
              ],
              "children": [
                {
                  "attr": {
                    "debugLine": "pages/index/index:30",
                    "className": "comment",
                    "value": function () {return this.inputValue}
                  },
                  "type": "input",
                  "classList": [
                    "comment"
                  ],
                  "events": {
                    "change": "updateValue"
                  }
                },
                {
                  "attr": {
                    "debugLine": "pages/index/index:31",
                    "className": "done-text",
                    "value": "提交"
                  },
                  "type": "text",
                  "classList": [
                    "done-text"
                  ],
                  "events": {
                    "click": "submitCommit"
                  }
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "attr": {
        "debugLine": "pages/index/index:36",
        "className": "right-container"
      },
      "type": "div",
      "classList": [
        "right-container"
      ],
      "children": [
        {
          "attr": {
            "debugLine": "pages/index/index:37",
            "className": "img",
            "src": function () {return this.middleImage}
          },
          "type": "image",
          "classList": [
            "img"
          ]
        }
      ]
    }
  ]
}

/***/ }),

/***/ "./lib/script.js!./node_modules/babel-loader/lib/index.js?presets[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.20\\build-tools\\ace-loader\\node_modules\\@babel\\preset-env&plugins[]=D:\\dev_hm\\hmSdk\\js\\2.1.1.20\\build-tools\\ace-loader\\node_modules\\@babel\\plugin-transform-modules-commonjs&comments=false!../../../../../hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.js":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./lib/script.js!./node_modules/babel-loader/lib?presets[]=D:/dev_hm/hmSdk/js/2.1.1.20/build-tools/ace-loader/node_modules/@babel/preset-env&plugins[]=D:/dev_hm/hmSdk/js/2.1.1.20/build-tools/ace-loader/node_modules/@babel/plugin-transform-modules-commonjs&comments=false!D:/dev_hm/hm_workspace/JS_second/entry/src/main/js/default/pages/index/index.js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function(module, exports, $app_require$){"use strict";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _system = _interopRequireDefault($app_require$("@app-module/system.router"));

var _default = {
  data: {
    title: "",
    headTitle: "Capture ",
    paragraphFirst: 'Capture the beauty of light during the transition and fusion of ice and water. At the instant of movement and stillness, softness and rigidity, force and beauty, condensing moving moments.',
    paragraphSecond: 'Reflecting the purity of nature, the innovative design upgrades your visual entertainment and ergonomic comfort. Effortlessly capture what you see and let it speak for what you feel.',
    middleImage: "/common/meinv.jpg",
    zanImagePressed: "/common/zan_pressed.jpg",
    zanImageNormal: "/common/zan_normal.jpg",
    isZan: false,
    number: 0,
    inputValue: "",
    isCommit: false,
    persons: []
  },
  onInit: function onInit() {
    this.title = this.$t('strings.world');
  },
  updateValue: function updateValue(e) {
    console.info("update value: " + e.text);
    this.inputValue = e.text;
  },
  submitCommit: function submitCommit() {
    this.isCommit = !this.isCommit;
    console.info("submitCommit value: " + this.inputValue);
  },
  clickZan: function clickZan() {
    console.info("update clickZan: ");
    this.number = this.number + 1;
    this.isZan = !this.isZan;
    this.persons = ['a', 'b', 'c'];
  },
  launch: function launch() {
    _system["default"].push({
      uri: 'pages/detail/detail'
    });
  }
};
exports["default"] = _default;
var moduleOwn = exports.default || module.exports;
var accessors = ['public', 'protected', 'private'];
if (moduleOwn.data && accessors.some(function (acc) {
    return moduleOwn[acc];
  })) {
  throw new Error('For VM objects, attribute data must not coexist with public, protected, or private. Please replace data with public.');
} else if (!moduleOwn.data) {
  moduleOwn.data = {};
  moduleOwn._descriptor = {};
  accessors.forEach(function(acc) {
    var accType = typeof moduleOwn[acc];
    if (accType === 'object') {
      moduleOwn.data = Object.assign(moduleOwn.data, moduleOwn[acc]);
      for (var name in moduleOwn[acc]) {
        moduleOwn._descriptor[name] = {access : acc};
      }
    } else if (accType === 'function') {
      console.warn('For VM objects, attribute ' + acc + ' value must not be a function. Change the value to an object.');
    }
  });
}}
/* generated by ace-loader */


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ })

/******/ });